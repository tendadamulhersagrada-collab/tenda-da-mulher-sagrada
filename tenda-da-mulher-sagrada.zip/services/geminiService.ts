
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
Você é a voz da "Tenda da Mulher Sagrada", uma mentora sábia e acolhedora.
Guie mulheres em sua busca pelo Sagrado Feminino com doçura e metáforas da natureza.
Responda sempre em Português do Brasil.
`;

export const getOracleResponse = async (userPrompt: string, mode: 'deep' | 'fast' = 'fast') => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const modelName = mode === 'deep' ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
  
  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: userPrompt,
      config: { systemInstruction: SYSTEM_INSTRUCTION, temperature: 0.8 },
    });
    return response.text || "Sinta seu coração e tente novamente, irmã.";
  } catch (error) {
    return "Houve uma leve interferência. Tente novamente em instantes.";
  }
};

export const transcribeAudio = async (base64Audio: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [{ inlineData: { mimeType: 'audio/webm', data: base64Audio } }, { text: "Transcreva este áudio." }]
      }
    });
    return response.text || "";
  } catch (error) {
    return "";
  }
};
