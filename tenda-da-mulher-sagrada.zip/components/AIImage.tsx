
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

interface AIImageProps {
  prompt: string;
  alt: string;
  className?: string;
}

const AIImage: React.FC<AIImageProps> = ({ prompt, alt, className }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateImage = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ text: `${prompt}, artistic watercolor painting, mystical aesthetic` }] },
          config: { imageConfig: { aspectRatio: "16:9" } }
        });
        const imagePart = response.candidates?.[0]?.content?.parts.find(part => part.inlineData);
        if (imagePart?.inlineData) setImageUrl(`data:image/png;base64,${imagePart.inlineData.data}`);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    generateImage();
  }, [prompt]);

  if (loading) return <div className={`bg-black/5 animate-pulse ${className}`} />;
  return <img src={imageUrl || ''} alt={alt} className={`object-cover ${className}`} />;
};

export default AIImage;
