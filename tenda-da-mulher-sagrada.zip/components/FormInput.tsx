
import React from 'react';

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

const FormInput: React.FC<FormInputProps> = ({ label, error, ...props }) => {
  return (
    <div className="w-full">
      <label className="block text-[10px] font-black uppercase text-black mb-2 tracking-widest">{label}</label>
      <input
        {...props}
        className={`w-full px-5 py-3 rounded-2xl border ${error ? 'border-red-500' : 'border-black/20'} focus:outline-none focus:ring-2 focus:ring-black bg-white/40 text-black text-sm`}
      />
      {error && <span className="text-red-700 text-[10px] mt-1 block font-bold uppercase">{error}</span>}
    </div>
  );
};

export default FormInput;
