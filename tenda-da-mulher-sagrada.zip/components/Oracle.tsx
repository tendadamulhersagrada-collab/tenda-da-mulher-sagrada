
import React, { useState, useRef, useEffect } from 'react';
import { getOracleResponse, transcribeAudio } from '../services/geminiService';
import { OracleMessage } from '../types';

const Oracle: React.FC = () => {
  const [messages, setMessages] = useState<OracleMessage[]>([{ role: 'model', text: 'Bem-vinda à nossa tenda, irmã. Qual busca aquece seu coração hoje?' }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userText = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setIsTyping(true);
    const response = await getOracleResponse(userText);
    setIsTyping(false);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
  };

  return (
    <section id="oraculo" className="py-20 bg-black/5 px-6">
      <div className="max-w-4xl mx-auto bg-white/20 rounded-[40px] border border-black/10 overflow-hidden flex flex-col h-[500px]">
        <div className="bg-black text-[#c4a484] p-6 font-serif text-xl">Oráculo da Tenda</div>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-4 rounded-2xl ${m.role === 'user' ? 'bg-black text-[#c4a484]' : 'bg-white/80'}`}>{m.text}</div>
            </div>
          ))}
          {isTyping && <div className="text-xs opacity-50">A Sábia está refletindo...</div>}
        </div>
        <div className="p-4 border-t border-black/10 flex gap-2">
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="Sua pergunta..." className="flex-1 px-6 py-3 rounded-full bg-white/50 outline-none" />
          <button onClick={handleSend} className="bg-black text-[#c4a484] px-6 py-3 rounded-full">➤</button>
        </div>
      </div>
    </section>
  );
};

export default Oracle;
